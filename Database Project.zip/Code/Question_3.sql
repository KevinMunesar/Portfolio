SELECT COUNT(FK_ticketType) AS Amount, type
FROM tickettype NATURAL JOIN ticket JOIN transaction 
ON ticket.FK_transID = transaction.transID
WHERE transaction.datetime > '2023/12/31'
GROUP BY type
ORDER BY Amount DESC