SELECT employeeName, FK_TourExhibitName AS ExhibitName
FROM employee JOIN tourtraining 
ON employee.empID = tourtraining.FK_TourEmpID
UNION
SELECT DISTINCT employeeName, ''
FROM employee