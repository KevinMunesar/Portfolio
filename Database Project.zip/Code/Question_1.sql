SELECT AVG(ALL score) as ScoreAverage
FROM survey
WHERE comments IS NOT NULL;