UPDATE tickettype
SET price = price * 1.05;