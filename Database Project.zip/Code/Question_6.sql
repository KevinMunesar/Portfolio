SELECT exhibitName
FROM exhibit
WHERE exhibitName LIKE "%King%"