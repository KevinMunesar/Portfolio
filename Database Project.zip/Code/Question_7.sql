SELECT DISTINCT name AS Names FROM creditcard
UNION
SELECT DISTINCT employeeName FROM employee